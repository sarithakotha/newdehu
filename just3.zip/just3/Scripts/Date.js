$(function () {
    $(".date").keydown(function (e) {
        switch (e.keyCode) {
            default:
                e.preventDefault();
                break;
        }
    });
    $(".free-range-date").keydown(function (e) {
        switch (e.keyCode) {
            default:
                e.preventDefault();
                break;
        }
    });
    $(".date-form-control").keydown(function (e) {
        switch (e.keyCode) {
            default:
                e.preventDefault();
                break;
        }
    });
    $(".date").datepicker({ minDate: new Date() });
    $(".free-range-date").datepicker();
    $(".date-form-control").datetimepicker({ minDate: new Date() });
});