﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace PurchReqV2.Utilities
{
    /// <summary>
    /// Summary description for DataUtility
    /// </summary>
    /// <summary>
    /// A common class to be used for all database interactions
    /// </summary>
    public class DataUtility : DlCommon, IDisposable
    {
        #region Properties

        #region Private

        private string _connectionString = "";
        private SqlConnection _conn;
        private bool _disposing;

        #endregion

        #region Public

        /// <summary>
        /// Gets the state of the connection.
        /// </summary>
        /// <value>
        /// The state of the connection.
        /// </value>
        public ConnectionState ConnState
        {
            get
            {
                if (_conn == null)
                {
                    return (ConnectionState.Closed);
                }
                return (_conn.State);
            }
        }

        #endregion

        #endregion

        #region Enumerations

        private enum ExecuteType
        {
            NonQuery,
            Scalar,
            Reader,
            DataRow,
            DataTable,
            DataSet
        }

        #endregion

        #region Delegates

        public delegate void Error(Exception errorObject);

        #endregion

        #region Events

        public event Error OnError;

        #endregion

        #region Constructors

        public DataUtility(string connectionString)
        {
            _connectionString = connectionString;
        }

        #endregion

        #region Methods

        #region Private

        /// <summary>
        /// Attempts to connect to the local datasource
        /// </summary>
        /// <returns>True if a connection was successful</returns>
        private bool IsConnected()
        {
            #region If the connection is already open, return true

            if (_conn != null && _conn.State == ConnectionState.Open)
            {
                return (true);
            }

            #endregion

            #region Reset the connection object and attempt to open it

            _conn = new SqlConnection();

            #region Get the connection string

            _connectionString = GetConnectionString();
            if (_connectionString == "")
            {
                return (false);
            }

            #endregion

            _conn.ConnectionString = _connectionString;
            _conn.Open();

            #endregion

            return (_conn.State == ConnectionState.Open);
        }

        /// <summary>
        /// Retrieves a connection string for the local TimeClock2009 database
        /// </summary>
        /// <returns>An empty string if an error occurs, else a valid connection string</returns>
        private string GetConnectionString()
        {
            return _connectionString;
        }

        /// <summary>
        /// Raises an OnError event to any subscribers
        /// </summary>
        /// <param name="error">An exception object to be passed to subscribers</param>
        private void ThrowError(Exception error)
        {
            if (OnError != null)
            {
                OnError(error);
            }
        }

        /// <summary>
        /// Raises an OnError event to any subscribers
        /// </summary>
        /// <param name="err">An error message to be passed to subscribers</param>
        private void ThrowError(string err)
        {
            var error = new Exception(err);
            ThrowError(error);
        }

        private Result Execute(out object returnValue, string storedProcedureName, Hashtable parameters, ExecuteType executeType)
        {
            #region Verify the connection

            if (!IsConnected())
            {
                returnValue = null;
                return (new Result(ResultType.Failure, new Exception("Connection Failed")));
            }

            #endregion

            var result = new Result();
            returnValue = null;
            SqlDataAdapter adapter = null;
            SqlCommand command = null;

            try
            {
                #region Create and set the command object

                command = new SqlCommand(storedProcedureName, _conn) { CommandType = CommandType.StoredProcedure };
                command.Parameters.Add("RETURN_VALUE", SqlDbType.Int);
                command.Parameters["RETURN_VALUE"].Direction = ParameterDirection.ReturnValue;
                command.CommandTimeout = 600;

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (string name in parameters.Keys)
                    {
                        command.Parameters.AddWithValue(name, parameters[name]);
                    }
                }

                #endregion

                DataTable dataTable;
                switch (executeType)
                {
                    #region Execute Non Query
                    case ExecuteType.NonQuery:
                        returnValue = command.ExecuteNonQuery();
                        break;
                    #endregion

                    #region Execute Scalar
                    case ExecuteType.Scalar:
                        returnValue = command.ExecuteScalar();
                        break;
                    #endregion

                    #region Execute Reader
                    case ExecuteType.Reader:
                        returnValue = command.ExecuteReader();
                        break;
                    #endregion

                    #region Execute DataRow
                    case ExecuteType.DataRow:
                        adapter = new SqlDataAdapter(command);
                        dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            returnValue = dataTable.Rows[0];
                        }
                        break;
                    #endregion

                    #region Execute DataTable
                    case ExecuteType.DataTable:
                        adapter = new SqlDataAdapter(command);
                        dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        returnValue = dataTable;
                        break;
                    #endregion

                    #region Execute DataSet
                    case ExecuteType.DataSet:
                        adapter = new SqlDataAdapter(command);
                        var dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        returnValue = dataSet;
                        break;
                    #endregion
                }

            }

            #region Error Handling
            catch (Exception exception)
            {
                result.ResultType = ResultType.Failure;
                result.Exception = exception;
                returnValue = null;
            }
            #endregion

            #region Cleanup
            finally
            {
                try { _conn.Close(); }
                catch { }
                try
                {
                    if (adapter != null) adapter.Dispose();
                }
                catch { }
                try
                {
                    if (command != null) command.Dispose();
                }
                catch { }
            }
            #endregion

            try
            {
                if (command != null) result.SqlReturnValue = (int)command.Parameters["RETURN_VALUE"].Value;
            }
            catch { }

            return result;
        }

        #endregion

        #region Public

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (!_disposing)
            {
                _disposing = true;
                try { _conn.Close(); }
                catch { }
                try { _conn.Dispose(); }
                catch { }
                GC.SuppressFinalize(this);
            }
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteNonQuery(string storedProcedureName, Hashtable parameters)
        {
            object returnValue;
            return Execute(out returnValue, storedProcedureName, parameters, ExecuteType.NonQuery);
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="scalar">The scalar.</param>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteScalar(out object scalar, string storedProcedureName, Hashtable parameters)
        {
            return Execute(out scalar, storedProcedureName, parameters, ExecuteType.Scalar);
        }

        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <param name="reader">The reader.</param>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteReader(out SqlDataReader reader, string storedProcedureName, Hashtable parameters)
        {
            object retval;
            Result r = Execute(out retval, storedProcedureName, parameters, ExecuteType.Reader);
            reader = (SqlDataReader)retval;
            return (r);
        }

        /// <summary>
        /// Executes the data row.
        /// </summary>
        /// <param name="dataRow">The data row.</param>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteDataRow(out DataRow dataRow, string storedProcedureName, Hashtable parameters)
        {
            object retval;
            Result r = Execute(out retval, storedProcedureName, parameters, ExecuteType.DataRow);
            dataRow = (DataRow)retval;
            return (r);
        }

        /// <summary>
        /// Executes the data table.
        /// </summary>
        /// <param name="dataTable">The data table.</param>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteDataTable(out DataTable dataTable, string storedProcedureName, Hashtable parameters)
        {
            object retval;
            Result r = Execute(out retval, storedProcedureName, parameters, ExecuteType.DataTable);
            dataTable = (DataTable)retval;
            return (r);
        }

        /// <summary>
        /// Executes the data set.
        /// </summary>
        /// <param name="dataSet">The data set.</param>
        /// <param name="storedProcedureName">Name of the stored procedure.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public Result ExecuteDataSet(out DataSet dataSet, string storedProcedureName, Hashtable parameters)
        {
            object retval;
            Result r = Execute(out retval, storedProcedureName, parameters, ExecuteType.DataSet);
            if (r.ResultType == ResultType.Success)
            {
                dataSet = (DataSet)retval;
            }
            else
            {
                dataSet = new DataSet();
            }
            return (r);
        }

        #endregion

        #endregion
    }

    /// <summary>
    /// A class containing data from the execution of the Data Utility
    /// </summary>
    public class Result : DlCommon
    {
        #region Properties

        #region Private

        private ResultType _resultType = ResultType.Success;
        private int _returnValue = -10000;

        #endregion

        #region Public

        /// <summary>
        /// Gets or Sets the ResultType for a Data Utility operation
        /// </summary>
        public new ResultType ResultType
        {
            get { return _resultType; }
            set { _resultType = value; }
        }

        /// <summary>
        /// Gets or Sets the exception object associated with a Data Utility call.  If ResultType is Success, Exception object is null.
        /// </summary>
        public Exception Exception { get; set; }

        /// <summary>
        /// Gets or sets the Return Value returned from SQL Server
        /// </summary>
        public int SqlReturnValue
        {
            get { return (_returnValue); }
            set { _returnValue = value; }
        }

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Result object associated with a Data Utility call
        /// </summary>
        public Result()
        {
            Exception = null;
        }

        /// <summary>
        /// Result object associated with a Data Utility call
        /// </summary>
        /// <param name="resultType">ResultType (Success or Failure) of the Data Utility call</param>
        public Result(ResultType resultType)
        {
            Exception = null;
            _resultType = resultType;
        }

        /// <summary>
        /// Result object associated with a Data Utility call
        /// </summary>
        /// <param name="resultType">ResultType (Success or Failure) of the Data Utility call</param>
        /// <param name="exception">If ResultType = Failure, this should hold the exception object</param>
        public Result(ResultType resultType, Exception exception)
        {
            Exception = null;
            _resultType = resultType;
            Exception = exception;
        }

        #endregion
    }

    /// <summary>
    /// A class containing an enum that is common to the Result and DataUtility classes
    /// </summary>
    public class DlCommon
    {
        public enum ResultType
        {
            Success,
            Failure
        }
    }
}