﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;

namespace PurchReqV2.Utilities
{
    /// <summary>
    /// ActiveDirectory Authentication Class
    /// </summary>
    public static class Ldap
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        #endregion

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Returns the active directory groups that the user belongs to. 
        /// AD authentication is based off of the ISrequest user.
        /// </summary>
        /// <param name="strUsername"></param>
        /// <returns>Authenticated user, if valid</returns>
        public static LdapUser GetUserInfo(string strUsername)
        { 
            if (!Config.UtilizePageLevelAccessRulesByAdUserOrGroup) { return new LdapUser(); }

            var adPath = Config.LdapPath;
            var user = new LdapUser();
            if (strUsername.Contains("\\"))
            {
                strUsername = strUsername.Substring(strUsername.IndexOf("\\", StringComparison.Ordinal) + 1,
                    strUsername.Length - strUsername.IndexOf("\\", StringComparison.Ordinal) - 1);
            }

            user.Name = strUsername;

            var entry = new DirectoryEntry(adPath)
            {
                Username = Config.LdapUser,
                Password = Config.LdapPassword
            };

            var search = new DirectorySearcher(entry) {Filter = "(SAMAccountName=" + strUsername + ")"};

            search.PropertiesToLoad.Add("cn");
            var result = search.FindOne();

            if (null == result)
            {
                return user;
            }

            var fullName = (String)result.Properties["cn"][0];

            user.Name = GetName(fullName);
            user.Groups = GetGroups(entry, fullName);

            

            return user;
        }

        /// <summary>
        /// Gets the groups.
        /// </summary>
        /// <param name="entry">The entry.</param>
        /// <param name="name">The name.</param>
        /// <returns>List of AD Groups</returns>
        public static List<String> GetGroups(DirectoryEntry entry, String name)
        {
            var search = new DirectorySearcher(entry) {Filter = "(cn=" + name + ")"};
            search.PropertiesToLoad.Add("memberOf");
            var groupNames = new List<String>();

            var result = search.FindOne();
            var propertyCount = result.Properties["memberOf"].Count;

            for (var propertyCounter = 0;
                propertyCounter < propertyCount;
                propertyCounter++)
            {
                var dn = (String)result.Properties["memberOf"][propertyCounter];

                var equalsIndex = dn.IndexOf("=", 1, StringComparison.Ordinal);
                var commaIndex = dn.IndexOf(",", 1, StringComparison.Ordinal);

                if (-1 == equalsIndex)
                {
                    return null;
                }
                groupNames.Add(dn.Substring((equalsIndex + 1),
                    (commaIndex - equalsIndex) - 1));
            }

            return groupNames;
        }

        #endregion

        #region Private Methods

        private static String GetName(String strName)
        {
            try
            {
                return strName.Substring(strName.IndexOf(",", StringComparison.Ordinal) + 1, strName.Length - (strName.IndexOf(",", StringComparison.Ordinal) + 1)) + " " +
                       strName.Substring(0, strName.IndexOf(",", StringComparison.Ordinal));
            }
            catch
            {
            }


            return strName;
        }

        #endregion

        #endregion
    }

    /// <summary>
    /// Represents an authenticated Windows login via Active Directory
    /// </summary>
    public class LdapUser
    {
        #region Variables

        #region Private Variables

        private String _name = "";
        private List<String> _groupList = new List<string>();

        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }

        #endregion

        #region Public Variables

        public List<String> Groups
        {
            get;
            set;
        }

        #endregion

        #endregion
    }
}