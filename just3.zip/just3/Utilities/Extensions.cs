﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PurchReqV2.Utilities
{
    /// <summary>
    /// Summary description for Extensions
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        ///  Extemsion used to create general objects using LINQ.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="table">The table.</param>
        /// <returns>IEnumerable of the specified object</returns>
        /// <exception cref="System.NullReferenceException">
        /// DataTable or Properties
        /// </exception>
        public static IEnumerable<T> AsEnumerable<T>(this DataTable table) where T : new()
        {
            if (table == null) { throw new NullReferenceException("DataTable"); }

            var propertiesLength = typeof(T).GetProperties().Length;

            if (propertiesLength == 0) { throw new NullReferenceException("Properties"); }

            var objList = new List<T>();

            foreach (DataRow row in table.Rows)
            {
                var obj = new T();

                var objProperties = obj.GetType().GetProperties();

                for (var i = 0; i < propertiesLength; i++)
                {
                    var property = objProperties[i];

                    if (table.Columns.Contains(property.Name))
                    {
                        var objValue = row[property.Name];

                        var propertyType = property.PropertyType;
                        if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                            propertyType = propertyType.GetGenericArguments()[0];

                        if (!(objValue is DBNull)) { objProperties[i].SetValue(obj, Convert.ChangeType(objValue, propertyType, System.Globalization.CultureInfo.CurrentCulture), null); }
                        else { objProperties[i].SetValue(obj, null, null); }
                    }
                }

                objList.Add(obj);
            }

            return objList;
        }

        /// <summary>
        /// Linqs to data table.
        /// </summary>
        /// <typeparam name="T">Default generic type</typeparam>
        /// <param name="varlist">The varlist.</param>
        /// <returns>Datatable</returns>
        public static DataTable LinqToDataTable<T>(IEnumerable<T> varlist)
        {
            var dtReturn = new DataTable();

            PropertyInfo[] oProps = null;

            if (varlist == null) return dtReturn;

            foreach (var rec in varlist)
            {
                if (oProps == null)
                {
                    oProps = (rec.GetType()).GetProperties();
                    foreach (var pi in oProps)
                    {
                        var colType = pi.PropertyType;

                        if ((colType.IsGenericType) && (colType.GetGenericTypeDefinition()
                                                        == typeof(Nullable<>)))
                        {
                            colType = colType.GetGenericArguments()[0];
                        }

                        dtReturn.Columns.Add(new DataColumn(pi.Name, colType));
                    }
                }

                var dr = dtReturn.NewRow();

                foreach (var pi in oProps)
                {
                    dr[pi.Name] = pi.GetValue(rec, null) ?? DBNull.Value;
                }

                dtReturn.Rows.Add(dr);
            }
            return dtReturn;
        }

        /// <summary>
        /// Gets the dictionary.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <returns>Dictionary</returns>
        public static Dictionary<int, string> GetDictionary(DataTable dt)
        {
            return dt.AsEnumerable()
              .ToDictionary(row => row.Field<int>(0),
                                        row => row.Field<string>(1));
        }

        /// <summary>
        /// Finds the control recursive.
        /// </summary>
        /// <param name="root">The root.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>Control or null</returns>
        public static Control FindControlRecursive(Control root, string id)
        {
            return root.ID == id ? root : (from Control c in root.Controls select FindControlRecursive(c, id)).FirstOrDefault(t => t != null);
        }

        /// <summary>
        /// Gets the name of the column index by.
        /// </summary>
        /// <param name="grid">The grid.</param>
        /// <param name="name">The name.</param>
        /// <returns>Int column index</returns>
        public static int GetColumnIndexByName(GridView grid, string name)
        {
            foreach (DataControlField col in grid.Columns.Cast<DataControlField>().Where(col => col.HeaderText.ToLower().Trim() == name.ToLower().Trim()))
            {
                return grid.Columns.IndexOf(col);
            }

            return -1;
        }

        /// <summary>
        /// Gets the 12:00:00 instance of a DateTime
        /// </summary>
        public static DateTime AbsoluteStart(this DateTime dateTime)
        {
            return dateTime.Date;
        }

        /// <summary>
        /// Gets the 11:59:59 instance of a DateTime
        /// </summary>
        public static DateTime AbsoluteEnd(this DateTime dateTime)
        {
            return AbsoluteStart(dateTime).AddDays(1).AddSeconds(-1);
        }

        /// <summary>
        /// Returns SQL type of the input.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns>SQL Type of given input or null</returns>
        public static SqlDbType GetSqlType(string input)
        {
            if (string.IsNullOrEmpty(input))
                throw new ArgumentException("The SQL Type being mapped cannot be null or empty.");

            var type = input.ToLower();
            var tokens = type.Split(new[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
            var typeFamily = tokens[0].ToLowerInvariant();

            switch (typeFamily)
            {
                case "bigint":
                    return SqlDbType.BigInt;
                case "binary":
                    return SqlDbType.Binary;
                case "bit":
                    return SqlDbType.Bit;
                case "char":
                    return SqlDbType.Char;
                case "datetime":
                    return SqlDbType.DateTime;
                case "datetime2":
                    return SqlDbType.DateTime2;
                case "decimal":
                    return SqlDbType.Decimal;
                case "float":
                    return SqlDbType.Float;
                case "image":
                    return SqlDbType.Image;
                case "int":
                    return SqlDbType.Int;
                case "money":
                    return SqlDbType.Money;
                case "nchar":
                    return SqlDbType.NChar;
                case "ntext":
                    return SqlDbType.NText;
                case "nvarchar":
                    return SqlDbType.NVarChar;
                case "real":
                    return SqlDbType.Real;
                case "uniqueidentifier":
                    return SqlDbType.UniqueIdentifier;
                case "smalldatetime":
                    return SqlDbType.SmallDateTime;
                case "smallint":
                    return SqlDbType.SmallInt;
                case "smallmoney":
                    return SqlDbType.SmallMoney;
                case "sql_variant":
                    return SqlDbType.Variant;
                case "text":
                    return SqlDbType.Text;
                case "timestamp":
                    return SqlDbType.Timestamp;
                case "tinyint":
                    return SqlDbType.TinyInt;
                case "varbinary":
                    return SqlDbType.VarBinary;
                case "varchar":
                    return SqlDbType.VarChar;
                case "variant":
                    return SqlDbType.Variant;
                case "xml":
                    return SqlDbType.Xml;
                default:
                    throw new ArgumentException("No SQL Data Type can be mapped to " + input + ".");
            }
        }

        /// <summary>
        /// Returns the type of the SQL type.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns>CLR Type of given input</returns>
        /// <exception cref="System.ArgumentException">If no SQL type can be determined</exception>
        public static Type SqlTypeToType(string input)
        {
            if (string.IsNullOrEmpty(input)) return null;

            var type = input.ToLower();
            var tokens = type.Split(new [] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
            var typeFamily = tokens[0].ToLowerInvariant();
            var size = tokens.Length > 1 ? tokens[1] : string.Empty;

            switch (typeFamily)
            {
                case "bigint":
                    return typeof(long);
                case "binary":
                    return size == "1" ? typeof(byte) : typeof(byte[]);
                case "bit":
                    return typeof(bool);
                case "char":
                    return size == "1" ? typeof(char) : typeof(string);
                case "datetime":
                    return typeof(DateTime);
                case "datetime2":
                    return typeof(DateTime?);
                case "decimal":
                    return typeof(decimal);
                case "float":
                    return typeof(double);
                case "image":
                    return typeof(byte[]);
                case "int":
                    return typeof(int);
                case "money":
                    return typeof(double);
                case "nchar":
                    return size == "1" ? typeof(char) : typeof(string);
                case "ntext":
                    return typeof(string);
                case "nvarchar":
                    return typeof(string);
                case "real":
                    return typeof(float);
                case "uniqueidentifier":
                    return typeof(Guid);
                case "smalldatetime":
                    return typeof(DateTime);
                case "smallint":
                    return typeof(short);
                case "smallmoney":
                    return typeof(float);
                case "sql_variant":
                    return typeof(string);
                case "text":
                    return typeof(string);
                case "timestamp":
                    return typeof(TimeSpan);
                case "tinyint":
                    return typeof(byte);
                case "varbinary":
                    return typeof(byte[]);
                case "varchar":
                    return typeof(string);
                case "variant":
                    return typeof(string);
                case "xml":
                    return typeof(string);
                default:
                    return null;
            }
        }

        /// <summary>
        /// Subs the specified arguments.
        /// </summary>
        /// <param name="format">The format.</param>
        /// <param name="args">The arguments.</param>
        /// <returns>sub'd arguments</returns>
        public static string Sub(this string format, params object[] args)
        {
            return string.Format(format, args);
        }

        /// <summary>
        /// Determines if this date is a federal holiday.
        /// </summary>
        /// <param name="date">This date</param>
        /// <returns>True if this date is a federal holiday</returns>
        public static bool IsFederalHoliday(this DateTime date)
        {
            // to ease typing
            int nthWeekDay = (int)(Math.Ceiling((double)date.Day / 7.0d));
            DayOfWeek dayName = date.DayOfWeek;
            bool isThursday = dayName == DayOfWeek.Thursday;
            bool isFriday = dayName == DayOfWeek.Friday;
            bool isMonday = dayName == DayOfWeek.Monday;
            bool isWeekend = dayName == DayOfWeek.Saturday || dayName == DayOfWeek.Sunday;

            // New Years Day (Jan 1, or preceding Friday/following Monday if weekend)
            if ((date.Month == 12 && date.Day == 31 && isFriday) ||
                (date.Month == 1 && date.Day == 1 && !isWeekend) ||
                (date.Month == 1 && date.Day == 2 && isMonday)) return true;

            // MLK day (3rd monday in January)
            if (date.Month == 1 && isMonday && nthWeekDay == 3) return true;

            // President’s Day (3rd Monday in February)
            if (date.Month == 2 && isMonday && nthWeekDay == 3) return true;

            // Memorial Day (Last Monday in May)
            if (date.Month == 5 && isMonday && date.AddDays(7).Month == 6) return true;

            // Independence Day (July 4, or preceding Friday/following Monday if weekend)
            if ((date.Month == 7 && date.Day == 3 && isFriday) ||
                (date.Month == 7 && date.Day == 4 && !isWeekend) ||
                (date.Month == 7 && date.Day == 5 && isMonday)) return true;

            // Labor Day (1st Monday in September)
            if (date.Month == 9 && isMonday && nthWeekDay == 1) return true;

            // Columbus Day (2nd Monday in October)
            if (date.Month == 10 && isMonday && nthWeekDay == 2) return true;

            // Veteran’s Day (November 11, or preceding Friday/following Monday if weekend))
            if ((date.Month == 11 && date.Day == 10 && isFriday) ||
                (date.Month == 11 && date.Day == 11 && !isWeekend) ||
                (date.Month == 11 && date.Day == 12 && isMonday)) return true;

            // Thanksgiving Day (4th Thursday in November)
            if (date.Month == 11 && isThursday && nthWeekDay == 4) return true;

            // Christmas Day (December 25, or preceding Friday/following Monday if weekend))
            if ((date.Month == 12 && date.Day == 24 && isFriday) ||
                (date.Month == 12 && date.Day == 25 && !isWeekend) ||
                (date.Month == 12 && date.Day == 26 && isMonday)) return true;

            return false;
        }
    }
}