﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using log4net;
using log4net.Appender;

namespace PurchReqV2.Utilities
{
    /// <summary>
    /// The main Logging utility
    /// Written By:  Matthew Stucki
    /// Written On:  12/28/2015
    /// </summary>
    public static class Logger
    {
        #region Variables and Whatnot
        private static readonly ILog _log;
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes the <see cref="Logger"/> class.
        /// </summary>
        static Logger()
        {
            GlobalContext.Properties["LogName"] = DateTime.Now.ToString("yyyy-MM") + ".log";
            log4net.Config.XmlConfigurator.Configure();
            _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            CreateRequiredDirectories();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        public static void Log(string message)
        {
            if (_log.IsDebugEnabled)
            {
                _log.Debug(message);
                CleanUp(DateTime.Now.AddMonths(-1));
            }
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="readableMessage">The readable message.</param>
        /// <param name="e">The e.</param>
        public static void LogException(string readableMessage, Exception e)
        {
            if (_log.IsErrorEnabled)
            {
                _log.Error(readableMessage, e);
                CleanUp(DateTime.Now.AddMonths(-1));
            }
        }

        #endregion

        #region Private Methods

        private static void CleanUp(DateTime date)
        {
            var directory = string.Empty;
            var fileSuffix = string.Empty;

            var repo = LogManager.GetAllRepositories().FirstOrDefault();
            if (repo == null)
                throw new NotSupportedException("Log4Net has not been configured yet.");

            var app = repo.GetAppenders().FirstOrDefault(x => x.GetType() == typeof(RollingFileAppender));
            if (app == null) return;
            log4net.Config.BasicConfigurator.Configure(app);
            var appender = app as RollingFileAppender;

            if (appender != null)
            {
                directory = Path.GetDirectoryName(appender.File);
                fileSuffix = Path.GetExtension(appender.File);
            }

            CleanUp(directory, fileSuffix, date);
        }

        private static void CleanUp(string logDirectory, string logSuffix, DateTime date)
        {
            if (string.IsNullOrEmpty(logDirectory))
                throw new ArgumentNullException("logDirectory");

            if (string.IsNullOrEmpty(logSuffix))
                throw new ArgumentNullException("logSuffix");

            var dirInfo = new DirectoryInfo(logDirectory);
            if (!dirInfo.Exists)
                return;

            var fileInfos = dirInfo.GetFiles("*{0}".Sub(logSuffix));
            if (fileInfos.Length == 0)
                return;

            foreach (var info in fileInfos.Where(info => info.LastWriteTime < date))
            {
                info.Delete();
            }

        }

        private static void CreateRequiredDirectories()
        {
            var repo = LogManager.GetAllRepositories().FirstOrDefault();
            if (repo == null)
                throw new NotSupportedException("Log4Net has not been configured yet.");

            var app = repo.GetAppenders().FirstOrDefault(x => x.GetType() == typeof(RollingFileAppender));
            if (app == null) return;
            log4net.Config.BasicConfigurator.Configure(app);
            var appender = app as RollingFileAppender;

            if (appender == null) return;
            var directory = Path.GetDirectoryName(appender.File);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
        }

        #endregion
    }
}
