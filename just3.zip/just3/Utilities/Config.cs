﻿using System;
using System.Configuration;

namespace PurchReqV2.Utilities
{
    /// <summary>
    /// General configurations for the PurchReqV2 website
    /// </summary>
    public static class Config
    {
        public static string PurchReqV2ConnectionString
        {
            get
            {
                return Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["development"].ToLower())
                    ? ConfigurationManager.ConnectionStrings["PurchReqV2DevConnectionString"].ConnectionString
                    : (Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["qa"].ToLower())
                        ? ConfigurationManager.ConnectionStrings["PurchReqV2QaConnectionString"].ConnectionString
                        : (Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["production"].ToLower())
                            ? ConfigurationManager.ConnectionStrings["PurchReqV2ProdConnectionString"].ConnectionString
                            : ConfigurationManager.ConnectionStrings["PurchReqV2DevConnectionString"].ConnectionString));
            }
        }

        public static string PagerSqlCommandPath
        {
            get
            {
                return ConfigurationManager.AppSettings["pagerSqlCommandPath"];
            }
        }

        public static string LdapPath
        {
            get
            {
                return ConfigurationManager.AppSettings["ldapPath"];
            }
        }

        public static string LdapUser
        {
            get
            {
                return Crypto.Decrypt(ConfigurationManager.AppSettings["ldapUser"], Passphrase);
            }
        }

        public static string LdapPassword
        {
            get
            {
                return Crypto.Decrypt(ConfigurationManager.AppSettings["ldapPassword"], Passphrase);
            }
        }

        public static string Passphrase
        {
            get
            {
                return ConfigurationManager.AppSettings["passphrase"];
            }
        }

        public static string SessionUserInfo
        {
            get
            {
                return ConfigurationManager.AppSettings["sessionUserInfo"];
            }
        }

        public static string SessionErrorMessage
        {
            get
            {
                return ConfigurationManager.AppSettings["sessionErrorMessage"];
            }
        }

        public static string SessionException
        {
            get
            {
                return ConfigurationManager.AppSettings["sessionException"];
            }
        }

        public static string SessionStackTrace
        {
            get
            {
                return ConfigurationManager.AppSettings["sessionStackTrace"];
            }
        }

        public static string SessionSiteMaintenance
        {
            get
            {
                return ConfigurationManager.AppSettings["sessionSiteMaintenance"];
            }
        }

        public static string MenuCss
        {
            get
            {
                return ConfigurationManager.AppSettings["mainMenuCss"];
            }
        }

        public static string SubMenuCss
        {
            get
            {
                return ConfigurationManager.AppSettings["subMenuCss"];
            }
        }

        public static string TailMenuCss
        {
            get
            {
                return ConfigurationManager.AppSettings["tailMenuCss"];
            }
        }

        public static string ImagePath
        {
            get
            {
                var path = Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["development"].ToLower())
                    ? ConfigurationManager.AppSettings["imagePathDev"].EndsWith("\\") ? ConfigurationManager.AppSettings["imagePathDev"] : ConfigurationManager.AppSettings["imagePathDev"] + "\\"
                    : (Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["qa"].ToLower())
                        ? ConfigurationManager.AppSettings["imagePathQa"].EndsWith("\\") ? ConfigurationManager.AppSettings["imagePathQa"] : ConfigurationManager.AppSettings["imagePathQa"] + "\\"
                        : (Environment.MachineName.ToLower().Contains(ConfigurationManager.AppSettings["production"].ToLower())
                            ? ConfigurationManager.AppSettings["imagePathProd"].EndsWith("\\") ? ConfigurationManager.AppSettings["imagePathProd"] : ConfigurationManager.AppSettings["imagePathProd"] + "\\"
                            : ConfigurationManager.AppSettings["imagePathDev"].EndsWith("\\") ? ConfigurationManager.AppSettings["imagePathDev"] : ConfigurationManager.AppSettings["imagePathDev"] + "\\"));

                if(string.IsNullOrEmpty(path)) throw new ApplicationException("The image configuration path is empty; no imaging functions will be available.");

                return path;
            }
        }

        public static string NoImageFileName
        {
            get
            {
                return ConfigurationManager.AppSettings["noImageFileName"];
            }
        }

        public static string DefaultAccountCat
        {
            get
            {
                return ConfigurationManager.AppSettings["defaultAccountCat"];
            }
        }

        public static string DefaultEmailTail
        {
            get
            {
                return ConfigurationManager.AppSettings["defaultEmailTail"];
            }
        }

        public static string NextSequenceProc
        {
            get
            {
                return ConfigurationManager.AppSettings["nextSequenceProc"];
            }
        }

        public static string NextStagingSequenceProc
        {
            get
            {
                return ConfigurationManager.AppSettings["nextStagingSequenceProc"];
            }
        }

        public static string MainValidationGroup
        {
            get
            {
                return ConfigurationManager.AppSettings["mainValidationGroup"];
            }
        }

        public static string EmailFrom
        {
            get
            {
                return ConfigurationManager.AppSettings["emailFrom"];
            }
        }

        public static string EmailFromName
        {
            get
            {
                return ConfigurationManager.AppSettings["emailFromName"];
            }
        }

        public static string EmailErrorTo
        {
            get
            {
                return ConfigurationManager.AppSettings["emailErrorTo"];
            }
        }

        public static string EmailErrorSubject
        {
            get
            {
                return ConfigurationManager.AppSettings["emailErrorSubject"];
            }
        }

        public static string EmailErrorPageBody
        {
            get
            {
                return ConfigurationManager.AppSettings["emailErrorPageBody"];
            }
        }

        public static string ExcelDefaultFileName
        {
            get
            {
                return ConfigurationManager.AppSettings["excelDefaultFileName"];
            }
        }

        public static string ExcelDefaultWorksheetName
        {
            get
            {
                return ConfigurationManager.AppSettings["excelDefaultWorksheetName"];
            }
        }

        public static string ExcelFileExtension
        {
            get
            {
                return ConfigurationManager.AppSettings["excelFileExtension"];
            }
        }

        public static string MenuChildrenProc
        {
            get
            {
                return ConfigurationManager.AppSettings["menuChildrenProc"];
            }
        }

        public static string MenuParentsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["menuParentsProc"];
            }
        }

        public static string GroupsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["groupsProc"];
            }
        }

        public static string UsersProc
        {
            get
            {
                return ConfigurationManager.AppSettings["usersProc"];
            }
        }

        public static string UserParentMenuItemsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["userParentMenuItemsProc"];
            }
        }

        public static string GroupParentMenuItemsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["groupParentMenuItemsProc"];
            }
        }

        public static string UserChildrenMenuItemsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["userChildrenMenuItemsProc"];
            }
        }

        public static string GroupChildrenMenuItemsProc
        {
            get
            {
                return ConfigurationManager.AppSettings["groupChildrenMenuItemsProc"];
            }
        }

        public static string SiteMaintenanceProc
        {
            get
            {
                return ConfigurationManager.AppSettings["siteMaintenanceProc"];
            }
        }

        public static string PushNotificationsForIbmProc
        {
            get
            {
                return ConfigurationManager.AppSettings["pushNotificationsForIbmProc"];
            }
        }

        public static string ErrorPage
        {
            get
            {
                return ConfigurationManager.AppSettings["errorPage"];
            }
        }

        public static string FourZeroOnePage
        {
            get
            {
                return ConfigurationManager.AppSettings["401Page"];
            }
        }

        public static string FourZeroFourPage
        {
            get
            {
                return ConfigurationManager.AppSettings["404Page"];
            }
        }

        public static string SiteMaintenancePage
        {
            get
            {
                return ConfigurationManager.AppSettings["siteMaintenancePage"];
            }
        }

        public static bool UtilizePageLevelAccessRulesByAdUserOrGroup
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["UtilizePageLevelAccessRulesByAdUserOrGroup"]);
            }
        }
    }
}