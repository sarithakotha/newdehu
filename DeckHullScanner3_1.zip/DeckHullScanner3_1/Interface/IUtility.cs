﻿namespace DeckHullScanner.Interface
{
    public interface IUtility
    {
        public string GetVersion();
        public string GetReleaseStage();
        public string GetReleaseName();
        public string GetReleaseVersion();
        public string GetReleaseDate();


    }
}
